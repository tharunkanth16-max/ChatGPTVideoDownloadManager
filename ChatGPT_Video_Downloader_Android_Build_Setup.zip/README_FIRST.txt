Android-only GitHub build instructions

1. In your GitHub repository, upload ChatGPT_Video_Downloader_Android_Source.zip and commit it.
2. In the repository, choose Add file > Create new file.
3. Name the new file exactly: .github/workflows/build-apk.yml
4. Copy the contents of build-apk.yml from this bundle into that new file and commit it.
5. Open the repository's Actions tab. Wait for “Build Android APK” to finish.
6. Open the successful workflow run and download the artifact named ChatGPTVideoDownloadManager-debug-apk.

This workflow builds a debug APK; it is not yet built or tested. Build may fail if dependencies or project source need changes. The ZIP is intentionally kept as a ZIP in the repository; the workflow extracts it on GitHub's runner.
